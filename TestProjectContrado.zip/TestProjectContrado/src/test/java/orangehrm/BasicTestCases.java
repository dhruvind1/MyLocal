package orangehrm;

import com.github.javafaker.Faker;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.ITestResult;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class BasicTestCases {

    public static WebDriver driver;
    public String firstname, lastname;

    @Test(priority = 0) //Test Case 1
    public void Login(){
        System.setProperty("webdriver.chrome.driver","chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        driver.get("https://opensource-demo.orangehrmlive.com");
        driver.findElement(By.id("txtUsername")).sendKeys("admin");
        driver.findElement(By.id("txtPassword")).sendKeys("admin123");
        driver.findElement(By.id("btnLogin")).click();

        if(driver.findElement(By.xpath("//h1[contains(text(),'Dashboard')]")).isDisplayed()){
            System.out.println("Test Case 1 is Passed : User logged into the system successfully and redirected to dashboard.");
            Reporter.log("Test Case 1 is Passed : User logged into the system successfully and redirected to dashboard.");
        }
        else {
            System.out.println("Test Case 1 is Failed");
            Reporter.log("Test Case 1 is Failed");
            try
            {
                TakesScreenshot ts=(TakesScreenshot)driver;
                File source=ts.getScreenshotAs(OutputType.FILE);
                FileUtils.copyFile(source, new File("./Screenshots/"+"Login"+".png"));
                System.out.println("Screenshot taken");
            }
            catch (Exception e)
            {
                System.out.println("Exception while taking screenshot "+e.getMessage());
            }
        }
    }

    @Test(priority = 1) //Test Case 2
    public void AddEmployee() throws InterruptedException {
        driver.findElement(By.xpath("//b[contains(text(),'PIM')]")).click();
        driver.findElement(By.linkText("Add Employee")).click();

        Faker faker = new Faker();
        firstname =faker.name().firstName();
        lastname = faker.name().lastName();

        driver.findElement(By.id("firstName")).sendKeys(firstname);
        driver.findElement(By.id("lastName")).sendKeys(lastname);
        List<WebElement> uploadFile = driver.findElements(By.id("photofile"));
        String filePath = System.getProperty("user.dir") + "/Profile.png";
        uploadFile.get(0).sendKeys(filePath);
        driver.findElement(By.id("btnSave")).click();
        Thread.sleep(3000);
        if(driver.findElement(By.xpath("//h1[contains(text(),'Personal Details')]")).isDisplayed()){
            String empfirstname = driver.findElement(By.id("personal_txtEmpFirstName")).getAttribute("value");
            String emplastname = driver.findElement(By.id("personal_txtEmpLastName")).getAttribute("value");
            System.out.println("Employee Name : " +empfirstname+" "+emplastname);
            if(firstname.equals(empfirstname) && lastname.equals(emplastname)){
                System.out.println("Test Case 2 is Passed : User redirected to employee list page and employee has been created successfully with entered firstname and lastname.");
                Reporter.log("Test Case 2 is Passed : User redirected to employee list page and employee has been created successfully with entered firstname and lastname.");
            }
            else{
                System.out.println("Test Case 2 is Failed : User redirected to employee list page but employee firstname and lastname is not matched with entered value.");
                Reporter.log("Test Case 2 is Failed : User redirected to employee list page but employee firstname and lastname is not matched with entered value.");
                try
                {
                    TakesScreenshot ts=(TakesScreenshot)driver;
                    File source=ts.getScreenshotAs(OutputType.FILE);
                    FileUtils.copyFile(source, new File("./Screenshots/"+"AddEmployee"+".png"));
                    System.out.println("Screenshot taken");
                }
                catch (Exception e)
                {
                    System.out.println("Exception while taking screenshot "+e.getMessage());
                }
            }
        }

        else{
            System.out.println("Test Case 2 is Failed : After click on save from add employee screen, user is not redirected to employee list page.");
            Reporter.log("Test Case 2 is Failed : After click on save from add employee screen, user is not redirected to employee list page.");
        }
    }

    @Test(priority = 2)//Test Case 3
    public void SearchEmployee() throws InterruptedException {
        driver.findElement(By.xpath("//b[contains(text(),'PIM')]")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("empsearch_employee_name_empName")).sendKeys(firstname+" "+lastname);
        driver.findElement(By.id("searchBtn")).click();
        Thread.sleep(5000);
        List<WebElement> rows = driver.findElements(By.xpath("//table[@class='table hover']/tbody/tr"));
        int count = rows.size();
        String employeedata = rows.get(0).getText();
        System.out.println("Employee Data : " +employeedata);
        if(count == 1 && employeedata.contains(firstname) && employeedata.contains(lastname))
        {
            System.out.println("Test Case 3 is Passed : Employee List is getting updated as per searched name and showing only 1 record on employee list page.");
            Reporter.log("Test Case 3 is Passed : Employee List is getting updated as per searched name and showing only 1 record on employee list page.");
        }
        else
        {
            System.out.println("Test Case 3 is Failed : Employee list is not getting updated as per searched name.");
            Reporter.log("Test Case 3 is Failed : Employee list is not getting updated as per searched name.");
            try
            {
                TakesScreenshot ts=(TakesScreenshot)driver;
                File source=ts.getScreenshotAs(OutputType.FILE);
                FileUtils.copyFile(source, new File("./Screenshots/"+"SearchEmployee"+".png"));
                System.out.println("Screenshot taken");
            }
            catch (Exception e)
            {
                System.out.println("Exception while taking screenshot "+e.getMessage());
            }
        }
    }
}
